package vue;

import java.awt.*;
import javax.swing.*;
import controleur.GestionnaireCours;
import modele.Equipes; 

public class DialogueListePersEquipe extends JDialog {

    public DialogueListePersEquipe(Frame parent, GestionnaireCours gestionnaire, FenetrePrincipale.ActionsCours action) {
        super(parent, "Liste du personnel de l'équipe", true); // true pour modal
        setSize(400, 300);
        setLocationRelativeTo(parent);
        
        // On ajoute les cours à une liste
        DefaultListModel<String> listeModele = new DefaultListModel<>();
        for(Equipes cours : gestionnaire.getListeEquipes()) {
            listeModele.addElement(cours.toString()); 
        }
        JList<String> liste = new JList<>(listeModele);
        JScrollPane scrollPane = new JScrollPane(liste);
        add(scrollPane);

        JButton okButton = new JButton("Fermer");
        okButton.addActionListener(e -> dispose());
        add(okButton, BorderLayout.SOUTH);

    }

}
