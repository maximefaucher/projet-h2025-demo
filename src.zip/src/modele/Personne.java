package modele;

import java.io.Serializable;

public abstract class Personne implements Serializable, Comparable<Personne> {

    protected String prenom;
    protected String nom;
    
    public Personne() {
        this.prenom = "Jean";
        this.nom = "Jean";
    }

    public Personne(String prenom, String nom) {
        this.prenom = prenom;
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }



    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((prenom == null) ? 0 : prenom.hashCode());
        result = prime * result + ((nom == null) ? 0 : nom.hashCode());
        return result;
    }


    public boolean equals(Personne obj) {
        return this.prenom.equals(obj.getPrenom()) && this.nom.equals(obj.getNom());
    }

    @Override
    public String toString() {
        return prenom + " " + nom;
    }

    // Ordre naturel : par nom puis par prénom
    public int compareTo(Personne o) {
        if (this.nom.equals(o.getNom())) {
            return this.prenom.compareTo(o.getPrenom());
        } else {
            return this.nom.compareTo(o.getNom());
        }
    }

}
