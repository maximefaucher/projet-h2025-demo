package modele;

public class Medecin {

}
