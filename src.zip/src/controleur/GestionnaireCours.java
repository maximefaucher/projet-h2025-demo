package controleur;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import modele.*;

public class GestionnaireCours {

    private ArrayList<Equipes> listeEquipes;
    public static final String NOM_FICHIER = "cours.dat"; // Nom du fichier de sauvegarde

    public GestionnaireCours() {
        this.listeEquipes = new ArrayList<Equipes>();
    }

    public ArrayList<Equipes> getListeEquipes() {
        return listeEquipes;
    }

    // Pour ajouter un cours
    public void ajouterCours(Equipes equipe) {
        this.listeEquipes.add(equipe);
    }

    // Pour supprimer un cours
    public void supprimerCours(Equipes equipe) {
        this.listeEquipes.remove(equipe);
    }

    // Pour remplacer un cours par un autre (mise à jour)
    public void remplacerCours(Equipes ancienCours, Equipes nouveauCours) {
        int index = this.listeEquipes.indexOf(ancienCours);
        if (index != -1) {
            this.listeEquipes.set(index, nouveauCours);
        }
    }

    // Pour récupérer les personnes d'un cours donné
    public ArrayList<Personne> getPersonnesDuCours(Equipes equipe) {
        return equipe.getPersonnes();
    }

    public void sauvegarderDansFichier(String nomFichier) throws IOException {
        // Mettre le code pour écrire l'ArrayList<Cours> dans un fichier sérialisé
        // TODO
    }

    @SuppressWarnings("unchecked") // pour éviter les avertissements de compilation
    public void chargerDepuisFichier(String nomFichier) throws IOException, ClassNotFoundException {
        // Mettre le code pour lire le fichier et récupérer l'ArrayList<Cours> sérialisée
        // TODO
        genererEquipesParDefaut(); // Si jamais le fichier n'existe pas ou que la liste est vide, on génère des cours par défaut
    }

    private void genererEquipesParDefaut() {
        // Créer des cours par défaut
        Equipes equipe1 = new Equipes("Les Chatouilleux Prisoniers", "Saint-Jérôme", new ArrayList<Personne>());
        Equipes equipe2 = new Equipes("Yvons d'Acier", "Nova-Scotia", new ArrayList<Personne>());
        Equipes equipe3 = new Equipes("Les Trains Immobilles", "Shawinigan", new ArrayList<Personne>());
        Equipes equipe4 = new Equipes("Les Crystales Bruns", "Bas-du-Cap", new ArrayList<Personne>());
        Equipes equipe5 = new Equipes("Dairy Queen", "Tokyo", new ArrayList<Personne>());
        Equipes equipe6 = new Equipes("mélasse", "NYC", new ArrayList<Personne>());
        Equipes equipe7 = new Equipes("ptits cocos du Sag", "Jonquière", new ArrayList<Personne>());
        equipe1.ajouterPersonne(new Entraineur("Marco","Pilieux",LocalDate.of(2001,2, 1),23, Disciplines.TypeEntr.ENTR_ADJOINT));
        // equipe1.ajouterPersonne(new Joueur("Bob", "Martin", LocalDate.of(2000, 3, 20), "123456", 95.5));
        // equipe1.ajouterPersonne(new Joueur("Charlie", "Durand", LocalDate.of(1999, 7, 10), "654321", 84.0));
        // Equipes cours2 = new Equipes("Développement Web II", Discipline.WEB, new ArrayList<Personne>());
        // cours2.ajouterPersonne(new Entraineur("David", "Leroy", LocalDate.of(1978, 11, 25), Discipline.BASES_DE_DONNEES, 3));
        // cours2.ajouterPersonne(new Joueur("Eve", "Bernard", LocalDate.of(2001, 1, 30), "789012", 88.0));
        // cours2.ajouterPersonne(new Joueur("Frank", "Lemoine", LocalDate.of(2002, 4, 5), "345678", 92.0));        
        // Equipes cours3 = new Equipes("Réseaux avancés", Discipline.RESEAUX, new ArrayList<Personne>());
        // cours3.ajouterPersonne(new Entraineur("Patrick", "Moreau", LocalDate.of(1990, 8, 12), Discipline.OBJETS_CONNECTES, 5));
        // cours3.ajouterPersonne(new Joueur("Hugo", "Rousseau", LocalDate.of(2003, 2, 14), "901234", 78.0));
        // cours3.ajouterPersonne(new Joueur("Iris", "Garnier", LocalDate.of(2004, 6, 18), "567890", 85.0));
        
        listeEquipes.add(equipe1);
        listeEquipes.add(equipe2);
        listeEquipes.add(equipe3);
        listeEquipes.add(equipe4);
        listeEquipes.add(equipe5);
        listeEquipes.add(equipe6);
        listeEquipes.add(equipe7);
        // listeEquipes.add(cours2);
        // listeEquipes.add(cours3);

        // Mélanger les listes (afin de tester les tris)
        Collections.shuffle(listeEquipes); // les cours
        for (Equipes cours : listeEquipes) { // les personnes dans les cours
            Collections.shuffle(cours.getPersonnes());
        }

    }

}
